# No shrinking rules required.
